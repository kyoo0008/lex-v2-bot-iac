def handler(event, context):

    print(event)

